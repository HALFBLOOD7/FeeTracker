package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity
import com.example.data.model.StudentWithDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface FeeDao {

    @Transaction
    @Query("SELECT * FROM students ORDER BY name ASC")
    fun getAllStudentsWithDetails(): Flow<List<StudentWithDetails>>

    @Transaction
    @Query("SELECT * FROM students WHERE studentId = :studentId")
    fun getStudentWithDetails(studentId: String): Flow<StudentWithDetails?>

    @Query("SELECT * FROM students WHERE studentId = :studentId")
    suspend fun getStudentById(studentId: String): StudentEntity?

    @Query("SELECT COUNT(*) FROM students")
    suspend fun getStudentCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun importStudents(students: List<StudentEntity>): List<Long>

    @Update
    suspend fun updateStudent(student: StudentEntity)

    @Delete
    suspend fun deleteStudent(student: StudentEntity)

    // Installments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstallments(installments: List<InstallmentEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun importInstallments(installments: List<InstallmentEntity>): List<Long>

    @Query("DELETE FROM installments WHERE studentId = :studentId")
    suspend fun deleteInstallmentsForStudent(studentId: String)

    @Query("SELECT * FROM installments WHERE studentId = :studentId ORDER BY dueDate ASC")
    fun getInstallmentsForStudent(studentId: String): Flow<List<InstallmentEntity>>

    // Payments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun importPayments(payments: List<PaymentEntity>): List<Long>

    @Delete
    suspend fun deletePayment(payment: PaymentEntity)

    @Query("SELECT * FROM payments ORDER BY payDate DESC")
    fun getAllPayments(): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE studentId = :studentId ORDER BY payDate DESC")
    fun getPaymentsForStudent(studentId: String): Flow<List<PaymentEntity>>

    @Transaction
    suspend fun saveStudentWithInstallments(
        student: StudentEntity,
        installments: List<InstallmentEntity>
    ) {
        insertStudent(student)
        deleteInstallmentsForStudent(student.studentId)
        if (installments.isNotEmpty()) {
            insertInstallments(installments)
        }
    }

    @Transaction
    suspend fun importBackup(
        students: List<StudentEntity>,
        installments: List<InstallmentEntity>,
        payments: List<PaymentEntity>
    ): Int {
        val importedStudents = if (students.isEmpty()) 0 else importStudents(students).count { it != -1L }
        val importedInstallments = if (installments.isEmpty()) 0 else importInstallments(installments).count { it != -1L }
        val importedPayments = if (payments.isEmpty()) 0 else importPayments(payments).count { it != -1L }
        return importedStudents + importedInstallments + importedPayments
    }

    @Query("DELETE FROM payments")
    suspend fun deleteAllPayments()

    @Query("DELETE FROM installments")
    suspend fun deleteAllInstallments()

    @Query("DELETE FROM students")
    suspend fun deleteAllStudents()
}

package com.example.data

import com.example.data.dao.FeeDao
import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity
import com.example.data.model.StudentFeeSummary
import com.example.data.model.StudentWithDetails
import com.example.domain.FeeCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FeeRepository(private val feeDao: FeeDao) {

    val allStudentsWithDetails: Flow<List<StudentWithDetails>> = feeDao.getAllStudentsWithDetails()

    val allSummaries: Flow<List<StudentFeeSummary>> = allStudentsWithDetails.map { list ->
        list.map { FeeCalculator.calculateSummary(it) }
    }

    val overdueSummaries: Flow<List<StudentFeeSummary>> = allSummaries.map { list ->
        list.filter { it.active && it.isOverdue }
            .sortedByDescending { it.overdue }
    }

    val allPayments: Flow<List<PaymentEntity>> = feeDao.getAllPayments()

    fun getStudentWithDetails(studentId: String): Flow<StudentWithDetails?> {
        return feeDao.getStudentWithDetails(studentId)
    }

    fun getStudentSummary(studentId: String): Flow<StudentFeeSummary?> {
        return feeDao.getStudentWithDetails(studentId).map { details ->
            details?.let { FeeCalculator.calculateSummary(it) }
        }
    }

    suspend fun saveStudentWithInstallments(
        student: StudentEntity,
        installments: List<InstallmentEntity>
    ) {
        feeDao.saveStudentWithInstallments(student, installments)
    }

    suspend fun updateStudent(student: StudentEntity) {
        feeDao.updateStudent(student)
    }

    suspend fun deleteStudent(student: StudentEntity) {
        feeDao.deleteStudent(student)
    }

    suspend fun recordPayment(payment: PaymentEntity) {
        feeDao.insertPayment(payment)
    }

    suspend fun deletePayment(payment: PaymentEntity) {
        feeDao.deletePayment(payment)
    }

    suspend fun resetWithDemoData() {
        feeDao.deleteAllPayments()
        feeDao.deleteAllInstallments()
        feeDao.deleteAllStudents()
        AppDatabase.seedInitialData(feeDao)
    }

    suspend fun checkAndSeedIfEmpty() {
        if (feeDao.getStudentCount() == 0) {
            AppDatabase.seedInitialData(feeDao)
        }
    }
}

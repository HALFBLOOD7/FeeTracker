package com.example

import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity
import com.example.data.model.StudentFeeSummary
import com.example.data.model.StudentWithDetails
import com.example.domain.FeeCalculator
import com.example.util.DateUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ExampleUnitTest {

    @Test
    fun testMonthlyPlanPeriodCalculation() {
        val startCal = Calendar.getInstance().apply {
            set(2026, Calendar.AUGUST, 15, 10, 0)
        }
        val todayCal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 28, 10, 0)
        }

        // August 15 to October 28:
        // yearDiff = 0, monthDiff = 9 - 7 = 2
        // day 28 >= 15 -> +1
        // Total periods = 3
        val periods = DateUtils.calculateMonthlyPeriodsDue(startCal.timeInMillis, todayCal.timeInMillis)
        assertEquals(3, periods)
    }

    @Test
    fun testAdvancePlanCalculation() {
        val student = StudentEntity(
            studentId = "adv-1",
            name = "Test Student",
            className = "10th",
            parentName = "Test Parent",
            phone = "9876543210",
            planType = StudentEntity.PLAN_ADVANCE,
            totalFee = 20000.0,
            monthlyFee = 0.0,
            startDate = DateUtils.daysAgo(10)
        )

        val payment = PaymentEntity(
            payId = "p-1",
            studentId = "adv-1",
            amount = 8000.0,
            mode = "UPI"
        )

        val details = StudentWithDetails(
            student = student,
            payments = listOf(payment)
        )

        val summary = FeeCalculator.calculateSummary(details)
        assertEquals(20000.0, summary.expected, 0.01)
        assertEquals(8000.0, summary.paid, 0.01)
        assertEquals(12000.0, summary.overdue, 0.01)
        assertEquals(StudentFeeSummary.STATUS_OVERDUE, summary.status)
        assertTrue(summary.waLink.contains("fee%20of%20Rs%2012000") || summary.waLink.contains("fee+of+Rs+12000") || summary.waLink.contains("12000"))
    }

    @Test
    fun testInstallmentPlanCalculation() {
        val student = StudentEntity(
            studentId = "inst-1",
            name = "Rohan",
            className = "12th",
            parentName = "Sunil",
            phone = "9812345678",
            planType = StudentEntity.PLAN_INSTALLMENT,
            totalFee = 30000.0,
            monthlyFee = 0.0,
            startDate = DateUtils.daysAgo(40)
        )

        val inst1 = InstallmentEntity("i1", "inst-1", DateUtils.daysAgo(30), 10000.0)
        val inst2 = InstallmentEntity("i2", "inst-1", DateUtils.daysAgo(5), 10000.0)
        val inst3 = InstallmentEntity("i3", "inst-1", DateUtils.daysFromNow(20), 10000.0)

        val payment = PaymentEntity("p1", "inst-1", DateUtils.daysAgo(25), 10000.0, "Cash")

        val details = StudentWithDetails(
            student = student,
            installments = listOf(inst1, inst2, inst3),
            payments = listOf(payment)
        )

        val summary = FeeCalculator.calculateSummary(details)
        // Inst 1 & 2 are due (20,000), Inst 3 is future.
        assertEquals(20000.0, summary.expected, 0.01)
        assertEquals(10000.0, summary.paid, 0.01)
        assertEquals(10000.0, summary.overdue, 0.01)
        assertEquals(StudentFeeSummary.STATUS_OVERDUE, summary.status)
    }

    @Test
    fun testMonthlyExpectedIsCappedAtContractFeeAndCanBeCleared() {
        val student = StudentEntity(
            studentId = "monthly-cap-1",
            name = "Monthly Student",
            className = "Class 10",
            parentName = "Parent",
            phone = "9876543210",
            planType = StudentEntity.PLAN_MONTHLY,
            totalFee = 3000.0,
            monthlyFee = 1000.0,
            startDate = DateUtils.daysAgo(120)
        )
        val payment = PaymentEntity(
            payId = "monthly-payment-1",
            studentId = student.studentId,
            amount = 3000.0,
            mode = PaymentEntity.MODE_UPI
        )
        val summary = FeeCalculator.calculateSummary(
            StudentWithDetails(student = student, payments = listOf(payment))
        )
        assertEquals(3000.0, summary.expected, 0.01)
        assertEquals(0.0, summary.overdue, 0.01)
        assertEquals(StudentFeeSummary.STATUS_CLEARED, summary.status)
    }

    @Test
    fun testClearedStatusCalculation() {
        val student = StudentEntity(
            studentId = "clr-1",
            name = "Ananya",
            className = "10th",
            parentName = "Manoj",
            phone = "9898989898",
            planType = StudentEntity.PLAN_ADVANCE,
            totalFee = 15000.0,
            monthlyFee = 0.0,
            startDate = DateUtils.daysAgo(20)
        )

        val payment = PaymentEntity("p1", "clr-1", DateUtils.daysAgo(15), 15000.0, "Cheque")

        val details = StudentWithDetails(
            student = student,
            payments = listOf(payment)
        )

        val summary = FeeCalculator.calculateSummary(details)
        assertEquals(0.0, summary.overdue, 0.01)
        assertEquals(StudentFeeSummary.STATUS_CLEARED, summary.status)
    }
}

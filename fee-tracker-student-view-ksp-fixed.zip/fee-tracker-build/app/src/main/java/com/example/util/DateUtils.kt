package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val displayDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val shortDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

    fun formatDate(timestamp: Long): String {
        return displayDateFormat.format(Date(timestamp))
    }

    fun formatShortDate(timestamp: Long): String {
        return shortDateFormat.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long): String {
        return "${displayDateFormat.format(Date(timestamp))} at ${timeFormat.format(Date(timestamp))}"
    }

    fun getStartOfDay(timestamp: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = timestamp
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun getEndOfDay(timestamp: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = timestamp
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        return cal.timeInMillis
    }

    fun daysAgo(days: Int): Long {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -days)
        }
        return cal.timeInMillis
    }

    fun daysFromNow(days: Int): Long {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, days)
        }
        return cal.timeInMillis
    }

    /**
     * Exact implementation of the AppSheet formula:
     * [MonthlyFee]*MAX(0,(YEAR(TODAY())-YEAR([StartDate]))*12+MONTH(TODAY())-MONTH([StartDate])+IF(DAY(TODAY())>=DAY([StartDate]),1,0))
     */
    fun calculateMonthlyPeriodsDue(startDateMillis: Long, todayMillis: Long = System.currentTimeMillis()): Int {
        val startCal = Calendar.getInstance().apply { timeInMillis = startDateMillis }
        val todayCal = Calendar.getInstance().apply { timeInMillis = todayMillis }

        val startYear = startCal.get(Calendar.YEAR)
        val startMonth = startCal.get(Calendar.MONTH) // 0 to 11
        val startDay = startCal.get(Calendar.DAY_OF_MONTH)

        val todayYear = todayCal.get(Calendar.YEAR)
        val todayMonth = todayCal.get(Calendar.MONTH)
        val todayDay = todayCal.get(Calendar.DAY_OF_MONTH)

        val yearDiff = todayYear - startYear
        val monthDiff = todayMonth - startMonth
        val dayAdjustment = if (todayDay >= startDay) 1 else 0

        val periods = (yearDiff * 12) + monthDiff + dayAdjustment
        return maxOf(0, periods)
    }
}

package com.example.data

import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity

/** CSV format used by Fee Tracker backups. It supports quoted commas, quotes and newlines. */
object ImportExportCsv {
    data class Backup(
        val students: List<StudentEntity>,
        val installments: List<InstallmentEntity>,
        val payments: List<PaymentEntity>
    )

    fun encode(students: List<StudentEntity>, installments: List<InstallmentEntity>, payments: List<PaymentEntity>): String {
        val out = StringBuilder()
        fun row(vararg values: Any?) {
            out.append(values.joinToString(",") { quote(it?.toString().orEmpty()) }).append("\r\n")
        }
        row("FEE_TRACKER_BACKUP", "1")
        row("STUDENTS")
        row("studentId", "name", "className", "parentName", "phone", "planType", "totalFee", "monthlyFee", "startDate", "active")
        students.forEach { row(it.studentId, it.name, it.className, it.parentName, it.phone, it.planType, it.totalFee, it.monthlyFee, it.startDate, it.active) }
        row("INSTALLMENTS")
        row("instId", "studentId", "dueDate", "amount")
        installments.forEach { row(it.instId, it.studentId, it.dueDate, it.amount) }
        row("PAYMENTS")
        row("payId", "studentId", "payDate", "amount", "mode", "note")
        payments.forEach { row(it.payId, it.studentId, it.payDate, it.amount, it.mode, it.note) }
        return out.toString()
    }

    fun decode(csv: String): Backup {
        val rows = parseRows(csv.removePrefix("\uFEFF"))
        require(rows.firstOrNull()?.take(2) == listOf("FEE_TRACKER_BACKUP", "1")) {
            "This is not a supported Fee Tracker backup. Export a fresh backup from Settings first."
        }
        val students = mutableListOf<StudentEntity>()
        val installments = mutableListOf<InstallmentEntity>()
        val payments = mutableListOf<PaymentEntity>()
        var section = ""
        var headerPending = false
        var header: List<String> = emptyList()
        rows.drop(1).forEachIndexed { index, row ->
            if (row.size == 1 && row[0].uppercase() in setOf("STUDENTS", "INSTALLMENTS", "PAYMENTS")) {
                section = row[0].uppercase()
                headerPending = true
                return@forEachIndexed
            }
            if (row.all { it.isBlank() }) return@forEachIndexed
            if (headerPending) {
                header = row
                headerPending = false
                return@forEachIndexed
            }
            try {
                val values = header.zip(row).toMap()
                fun value(key: String) = values[key] ?: error("Missing column '$key'")
                fun amount(key: String) = value(key).toDouble().also { require(it.isFinite() && it >= 0.0) { "Invalid $key" } }
                fun millis(key: String) = value(key).toLong().also { require(it >= 0L) { "Invalid $key" } }
                when (section) {
                    "STUDENTS" -> {
                        val plan = value("planType")
                        require(plan in setOf(StudentEntity.PLAN_MONTHLY, StudentEntity.PLAN_INSTALLMENT, StudentEntity.PLAN_ADVANCE)) { "Invalid plan type" }
                        students += StudentEntity(
                            studentId = value("studentId").also { require(it.isNotBlank()) },
                            name = value("name").also { require(it.isNotBlank()) },
                            className = value("className"), parentName = value("parentName"), phone = value("phone"),
                            planType = plan, totalFee = amount("totalFee"), monthlyFee = amount("monthlyFee"),
                            startDate = millis("startDate"), active = value("active").toBooleanStrict()
                        )
                    }
                    "INSTALLMENTS" -> installments += InstallmentEntity(
                        instId = value("instId").also { require(it.isNotBlank()) },
                        studentId = value("studentId").also { require(it.isNotBlank()) },
                        dueDate = millis("dueDate"), amount = amount("amount").also { require(it > 0.0) }
                    )
                    "PAYMENTS" -> payments += PaymentEntity(
                        payId = value("payId").also { require(it.isNotBlank()) },
                        studentId = value("studentId").also { require(it.isNotBlank()) },
                        payDate = millis("payDate"), amount = amount("amount").also { require(it > 0.0) },
                        mode = value("mode").also { require(it in PaymentEntity.ALL_MODES) }, note = value("note")
                    )
                    else -> error("Unexpected row outside a data section")
                }
            } catch (e: Exception) {
                throw IllegalArgumentException("Invalid backup row ${index + 3}: ${e.message ?: "invalid value"}", e)
            }
        }
        require(students.map { it.studentId }.distinct().size == students.size) { "Backup contains duplicate student IDs" }
        require(installments.map { it.instId }.distinct().size == installments.size) { "Backup contains duplicate installment IDs" }
        require(payments.map { it.payId }.distinct().size == payments.size) { "Backup contains duplicate payment IDs" }
        val studentIds = students.map { it.studentId }.toSet()
        require(installments.all { it.studentId in studentIds } && payments.all { it.studentId in studentIds }) {
            "Backup contains installments or payments without a matching student"
        }
        return Backup(students, installments, payments)
    }

    private fun quote(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun parseRows(input: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < input.length) {
            val c = input[i]
            when {
                quoted && c == '"' && i + 1 < input.length && input[i + 1] == '"' -> { field.append('"'); i++ }
                c == '"' -> quoted = !quoted
                !quoted && c == ',' -> { row += field.toString(); field.setLength(0) }
                !quoted && (c == '\n' || c == '\r') -> {
                    if (c == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
                    row += field.toString(); field.setLength(0)
                    rows += row.toList(); row = mutableListOf()
                }
                else -> field.append(c)
            }
            i++
        }
        require(!quoted) { "CSV has an unclosed quoted field" }
        if (field.isNotEmpty() || row.isNotEmpty()) { row += field.toString(); rows += row.toList() }
        return rows
    }
}

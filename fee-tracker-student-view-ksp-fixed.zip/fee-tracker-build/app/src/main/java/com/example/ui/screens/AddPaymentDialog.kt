package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentFeeSummary
import com.example.ui.components.formatCurrency
import com.example.ui.theme.ClearedGreen
import com.example.ui.theme.OverdueRed
import com.example.util.DateUtils
import com.example.ui.viewmodel.FeeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPaymentBottomSheet(
    student: StudentFeeSummary,
    viewModel: FeeViewModel,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    // Default amount: pre-fill with overdue if > 0, else 1000
    val defaultAmount = if (student.overdue > 0) {
        if (student.overdue % 1.0 == 0.0) student.overdue.toLong().toString() else "%.2f".format(student.overdue)
    } else ""

    var amountText by remember { mutableStateOf(defaultAmount) }
    var selectedMode by remember { mutableStateOf(PaymentEntity.MODE_UPI) }
    var noteText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
                .testTag("receive_payment_sheet")
        ) {
            Text(
                text = "Receive Fee Payment",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Student Overview Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = student.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${student.className} • ${student.parentName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Current Overdue",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "₹${formatCurrency(student.overdue)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (student.overdue > 0) OverdueRed else ClearedGreen
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Amount Field
            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    errorMessage = null
                },
                label = { Text("Payment Amount (₹)") },
                placeholder = { Text("e.g. 5000") },
                prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = errorMessage != null,
                supportingText = {
                    if (errorMessage != null) {
                        Text(text = errorMessage!!, color = OverdueRed)
                    } else {
                        Text(text = "Pre-filled with overdue amount. Change for partial payment.")
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("payment_amount_input")
            )

            // Quick preset chips if overdue exists
            if (student.overdue > 0) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    FilterChip(
                        selected = amountText == defaultAmount,
                        onClick = { amountText = defaultAmount },
                        label = { Text("Full Overdue (₹${formatCurrency(student.overdue)})", fontSize = 12.sp) }
                    )
                    if (student.overdue > 2000) {
                        val half = (student.overdue / 2).toLong()
                        FilterChip(
                            selected = amountText == half.toString(),
                            onClick = { amountText = half.toString() },
                            label = { Text("Half (₹${formatCurrency(half.toDouble())})", fontSize = 12.sp) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Payment Mode selector
            Text(
                text = "Payment Mode",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PaymentEntity.ALL_MODES.forEach { mode ->
                    FilterChip(
                        selected = selectedMode == mode,
                        onClick = { selectedMode = mode },
                        label = { Text(mode, fontSize = 13.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Note / Reference text
            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                label = { Text("Reference / Note (Optional)") },
                placeholder = { Text("e.g. UPI Ref #49281, Cheque #102, Cash by father") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("payment_note_input")
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Submit Buttons
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0) {
                        errorMessage = "Please enter a valid payment amount."
                        return@Button
                    }

                    viewModel.recordPayment(
                        studentId = student.studentId,
                        amount = amount,
                        mode = selectedMode,
                        note = noteText.trim(),
                        payDate = System.currentTimeMillis()
                    ) { recordedPayment, updatedSummary ->
                        onDismiss()
                        Toast.makeText(context, "Payment of ₹${formatCurrency(amount)} recorded successfully!", Toast.LENGTH_SHORT).show()

                        // Automatically launch receipt view
                        val remaining = maxOf(0.0, student.overdue - amount)
                        viewModel.showReceipt(
                            FeeViewModel.ReceiptData(
                                payment = recordedPayment,
                                studentName = student.name,
                                className = student.className,
                                parentName = student.parentName,
                                phone = student.phone,
                                remainingOverdue = remaining
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("confirm_payment_button")
            ) {
                Text(
                    text = "Confirm & Record Payment",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            TextButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cancel")
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

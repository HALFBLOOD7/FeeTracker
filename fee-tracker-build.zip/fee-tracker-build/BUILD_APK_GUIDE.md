# Build Fee Tracker APK

This project is prepared for a debug APK build. The debug build uses the standard Android Gradle Plugin debug signing key, so a project-specific `debug.keystore` is not required.

## Build on your computer

1. Install Android Studio and its Android SDK (including the SDK platform/build tools required by `compileSdk` in `app/build.gradle.kts`).
2. Open this project folder in Android Studio and allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, with Java 17, Android SDK configured, and Gradle 9.3.1 installed, run from the project root:

```bash
gradle --no-daemon assembleDebug
```

## Build in GitHub Actions

1. Create a GitHub repository and upload/push all files in this project to its `main` branch.
2. Open the repository's **Actions** tab and run **Build Fee Tracker APK** (or push to `main`/`master`).
3. Open the completed workflow run and download the `fee-tracker-debug-apk` artifact.
4. Extract the artifact to get the `.apk` file.

The workflow is a build configuration, not a prebuilt APK. The build must complete successfully before an APK artifact is available.

## Notes

- This produces a debug APK for testing/sideloading, not a Play Store release APK.
- The project contains `.env.example`; provide any required API key in a local `.env` file if the app's AI features need it. Never commit real API keys to a public repository.

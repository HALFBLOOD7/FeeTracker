package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey
    val studentId: String = UUID.randomUUID().toString(),
    val name: String,
    val className: String,
    val parentName: String,
    val phone: String,
    val planType: String, // "Monthly", "Installment", "Advance"
    val totalFee: Double,
    val monthlyFee: Double,
    val startDate: Long,
    val active: Boolean = true
) {
    companion object {
        const val PLAN_MONTHLY = "Monthly"
        const val PLAN_INSTALLMENT = "Installment"
        const val PLAN_ADVANCE = "Advance"
    }
}

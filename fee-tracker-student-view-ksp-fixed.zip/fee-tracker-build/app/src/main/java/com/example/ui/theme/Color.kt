package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors
val BrandPrimary = Color(0xFF0284C7) // Sky 600
val BrandPrimaryDark = Color(0xFF38BDF8)
val BrandSecondary = Color(0xFF0F766E) // Teal 700
val BrandSecondaryDark = Color(0xFF2DD4BF)
val BrandTertiary = Color(0xFFD97706) // Amber 600
val BrandTertiaryDark = Color(0xFFFBBF24)

// Surface & Background
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF020617)

// Status colors
val OverdueRed = Color(0xFFE11D48)
val OverdueContainer = Color(0xFFFFE4E6)
val OnOverdueContainer = Color(0xFF9F1239)

val ClearedGreen = Color(0xFF059669)
val ClearedContainer = Color(0xFFD1FAE5)
val OnClearedContainer = Color(0xFF065F46)

val OnTrackBlue = Color(0xFF0284C7)
val OnTrackContainer = Color(0xFFE0F2FE)
val OnOnTrackContainer = Color(0xFF075985)

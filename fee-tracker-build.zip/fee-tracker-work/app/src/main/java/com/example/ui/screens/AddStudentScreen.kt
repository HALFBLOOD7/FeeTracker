package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InstallmentEntity
import com.example.data.model.StudentEntity
import com.example.data.model.StudentWithDetails
import com.example.ui.components.formatCurrency
import com.example.ui.theme.ClearedGreen
import com.example.ui.theme.OverdueRed
import com.example.util.DateUtils
import com.example.ui.viewmodel.FeeViewModel
import java.util.Calendar
import java.util.UUID

data class TempInstallment(
    val id: String = UUID.randomUUID().toString(),
    var dueDate: Long,
    var amount: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddStudentScreen(
    viewModel: FeeViewModel,
    existingStudent: StudentWithDetails? = null,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isEditMode = existingStudent != null

    var name by remember { mutableStateOf(existingStudent?.student?.name ?: "") }
    var className by remember { mutableStateOf(existingStudent?.student?.className ?: "") }
    var parentName by remember { mutableStateOf(existingStudent?.student?.parentName ?: "") }
    var phone by remember { mutableStateOf(existingStudent?.student?.phone ?: "") }
    var planType by remember { mutableStateOf(existingStudent?.student?.planType ?: StudentEntity.PLAN_MONTHLY) }
    var totalFeeText by remember {
        mutableStateOf(
            if (existingStudent != null && existingStudent.student.totalFee > 0) {
                if (existingStudent.student.totalFee % 1.0 == 0.0) existingStudent.student.totalFee.toLong().toString()
                else existingStudent.student.totalFee.toString()
            } else ""
        )
    }
    var monthlyFeeText by remember {
        mutableStateOf(
            if (existingStudent != null && existingStudent.student.monthlyFee > 0) {
                if (existingStudent.student.monthlyFee % 1.0 == 0.0) existingStudent.student.monthlyFee.toLong().toString()
                else existingStudent.student.monthlyFee.toString()
            } else ""
        )
    }
    var startDate by remember { mutableLongStateOf(existingStudent?.student?.startDate ?: System.currentTimeMillis()) }
    var active by remember { mutableStateOf(existingStudent?.student?.active ?: true) }

    // Installments list for Installment plan
    val installments = remember {
        mutableStateListOf<TempInstallment>().apply {
            if (existingStudent != null && existingStudent.installments.isNotEmpty()) {
                addAll(
                    existingStudent.installments.map {
                        TempInstallment(
                            id = it.instId,
                            dueDate = it.dueDate,
                            amount = it.amount
                        )
                    }
                )
            }
        }
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun showDatePicker(initialDate: Long, onDateSelected: (Long) -> Unit) {
        val cal = Calendar.getInstance().apply { timeInMillis = initialDate }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    set(Calendar.HOUR_OF_DAY, 12)
                    set(Calendar.MINUTE, 0)
                }
                onDateSelected(selectedCal.timeInMillis)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditMode) "Edit Student" else "Add New Student") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .testTag("add_student_form"),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // General Info Header
            item {
                Text(
                    text = "Student Information",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Name
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    label = { Text("Student Name *") },
                    placeholder = { Text("e.g. Aarav Sharma") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_name")
                )
            }

            // Class & Grade
            item {
                OutlinedTextField(
                    value = className,
                    onValueChange = { className = it; errorMessage = null },
                    label = { Text("Class / Course *") },
                    placeholder = { Text("e.g. Class 10-A, Physics Batch 1") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_class")
                )
            }

            // Parent Name & Phone
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = parentName,
                        onValueChange = { parentName = it; errorMessage = null },
                        label = { Text("Parent / Guardian *") },
                        placeholder = { Text("e.g. Rajesh Sharma") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_student_parent")
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it; errorMessage = null },
                        label = { Text("Phone Number *") },
                        placeholder = { Text("e.g. 9876543210") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_student_phone")
                    )
                }
            }

            // Plan Type Selection
            item {
                Column {
                    Text(
                        text = "Fee Payment Plan *",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            StudentEntity.PLAN_MONTHLY to "Monthly",
                            StudentEntity.PLAN_INSTALLMENT to "Installment",
                            StudentEntity.PLAN_ADVANCE to "Advance"
                        ).forEach { (plan, label) ->
                            FilterChip(
                                selected = planType == plan,
                                onClick = {
                                    planType = plan
                                    errorMessage = null
                                },
                                label = { Text(label, fontWeight = FontWeight.SemiBold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Fees based on PlanType
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Fee
                    OutlinedTextField(
                        value = totalFeeText,
                        onValueChange = { totalFeeText = it; errorMessage = null },
                        label = { Text("Total Course Fee (₹) *") },
                        placeholder = { Text("e.g. 36000") },
                        prefix = { Text("₹ ") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_total_fee")
                    )

                    // Monthly Fee: Show_If [PlanType]="Monthly" (Step 2 rule)
                    if (planType == StudentEntity.PLAN_MONTHLY) {
                        OutlinedTextField(
                            value = monthlyFeeText,
                            onValueChange = { monthlyFeeText = it; errorMessage = null },
                            label = { Text("Monthly Fee (₹) *") },
                            placeholder = { Text("e.g. 3000") },
                            prefix = { Text("₹ ") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_monthly_fee")
                        )
                    }
                }
            }

            // Start Date (Date picker with past date support for testing)
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showDatePicker(startDate) { startDate = it }
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Start Date *",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = DateUtils.formatDate(startDate),
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                        TextButton(onClick = { showDatePicker(startDate) { startDate = it } }) {
                            Text("Change Date")
                        }
                    }
                }
            }

            // Quick past date buttons for easy testing as requested in prompt:
            // "Test it: add one student per plan with a past StartDate, check that Overdue shows the right amount"
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Quick Start:",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { startDate = System.currentTimeMillis() },
                        label = { Text("Today", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { startDate = DateUtils.daysAgo(30) },
                        label = { Text("1 Mo Ago", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { startDate = DateUtils.daysAgo(60) },
                        label = { Text("2 Mo Ago", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { startDate = DateUtils.daysAgo(90) },
                        label = { Text("3 Mo Ago", fontSize = 11.sp) }
                    )
                }
            }

            // Installment Plan inline section (Step 2 & Step 5)
            if (planType == StudentEntity.PLAN_INSTALLMENT) {
                item {
                    val installmentsSum = installments.sumOf { it.amount }
                    val targetFee = totalFeeText.toDoubleOrNull() ?: 0.0

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Installments Schedule",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Total Scheduled: ₹${formatCurrency(installmentsSum)} / ₹${formatCurrency(targetFee)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (targetFee > 0 && installmentsSum == targetFee) ClearedGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                TextButton(
                                    onClick = {
                                        installments.add(
                                            TempInstallment(
                                                dueDate = DateUtils.daysFromNow(30 * (installments.size + 1)),
                                                amount = 5000.0
                                            )
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Row")
                                }
                            }

                            // Auto-Split Presets
                            if (targetFee > 0) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Auto-Split:", style = MaterialTheme.typography.labelSmall)
                                    listOf(2, 3, 4, 6).forEach { parts ->
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                installments.clear()
                                                val partAmount = (targetFee / parts).toLong().toDouble()
                                                for (i in 0 until parts) {
                                                    val due = if (i == 0) startDate else DateUtils.daysFromNow(30 * i)
                                                    installments.add(TempInstallment(dueDate = due, amount = partAmount))
                                                }
                                            },
                                            label = { Text("$parts Parts", fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            installments.forEachIndexed { index, inst ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "#${index + 1}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.width(24.dp)
                                    )

                                    // Due Date button
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .weight(1.3f)
                                            .clickable {
                                                showDatePicker(inst.dueDate) { selectedDate ->
                                                    inst.dueDate = selectedDate
                                                    // trigger recompose
                                                    val copy = installments.toList()
                                                    installments.clear()
                                                    installments.addAll(copy)
                                                }
                                            }
                                    ) {
                                        Text(
                                            text = DateUtils.formatShortDate(inst.dueDate),
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)
                                        )
                                    }

                                    // Amount
                                    OutlinedTextField(
                                        value = if (inst.amount % 1.0 == 0.0) inst.amount.toLong().toString() else inst.amount.toString(),
                                        onValueChange = {
                                            val newAmt = it.toDoubleOrNull() ?: 0.0
                                            inst.amount = newAmt
                                        },
                                        placeholder = { Text("Amount") },
                                        prefix = { Text("₹", fontSize = 12.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    IconButton(
                                        onClick = { installments.removeAt(index) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = OverdueRed,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Active Student Toggle
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Active Student Status",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Inactive students are excluded from overdue notifications",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = active,
                        onCheckedChange = { active = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // Error display
            if (errorMessage != null) {
                item {
                    Text(
                        text = errorMessage!!,
                        color = OverdueRed,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            // Save Button
            item {
                Button(
                    onClick = {
                        val cleanName = name.trim()
                        val cleanClass = className.trim()
                        val cleanParent = parentName.trim()
                        val cleanPhone = phone.trim()
                        val totalFee = totalFeeText.toDoubleOrNull() ?: 0.0
                        val monthlyFee = if (planType == StudentEntity.PLAN_MONTHLY) {
                            monthlyFeeText.toDoubleOrNull() ?: 0.0
                        } else 0.0

                        if (cleanName.isBlank()) {
                            errorMessage = "Please enter student name."
                            return@Button
                        }
                        if (cleanClass.isBlank()) {
                            errorMessage = "Please enter class/course."
                            return@Button
                        }
                        if (cleanParent.isBlank()) {
                            errorMessage = "Please enter parent name."
                            return@Button
                        }
                        if (cleanPhone.isBlank()) {
                            errorMessage = "Please enter phone number."
                            return@Button
                        }
                        if (totalFee <= 0) {
                            errorMessage = "Please enter a valid total fee."
                            return@Button
                        }
                        if (planType == StudentEntity.PLAN_MONTHLY && monthlyFee <= 0) {
                            errorMessage = "Please enter a valid monthly fee."
                            return@Button
                        }
                        if (planType == StudentEntity.PLAN_INSTALLMENT && installments.isEmpty()) {
                            errorMessage = "Please add at least one installment row."
                            return@Button
                        }

                        val studentId = existingStudent?.student?.studentId ?: UUID.randomUUID().toString()
                        val student = StudentEntity(
                            studentId = studentId,
                            name = cleanName,
                            className = cleanClass,
                            parentName = cleanParent,
                            phone = cleanPhone,
                            planType = planType,
                            totalFee = totalFee,
                            monthlyFee = monthlyFee,
                            startDate = startDate,
                            active = active
                        )

                        val installmentEntities = if (planType == StudentEntity.PLAN_INSTALLMENT) {
                            installments.map {
                                InstallmentEntity(
                                    instId = it.id,
                                    studentId = studentId,
                                    dueDate = it.dueDate,
                                    amount = it.amount
                                )
                            }
                        } else emptyList()

                        viewModel.saveStudent(student, installmentEntities)
                        Toast.makeText(context, "Student saved successfully!", Toast.LENGTH_SHORT).show()
                        onBack()
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_student_button")
                ) {
                    Icon(Icons.Default.Done, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEditMode) "Save Changes" else "Add Student",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

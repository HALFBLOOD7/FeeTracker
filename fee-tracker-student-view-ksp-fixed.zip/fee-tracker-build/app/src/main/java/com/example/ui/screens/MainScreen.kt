package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Payment
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.OverdueRed
import com.example.ui.viewmodel.FeeViewModel

enum class MainTab(val label: String) {
    DASHBOARD("Dashboard"),
    OVERDUE("Overdue"),
    STUDENTS("Students"),
    PAYMENTS("Payments"),
    SETTINGS("Settings")
}

@Composable
fun MainScreen(
    viewModel: FeeViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(MainTab.DASHBOARD) }

    val selectedStudentId by viewModel.selectedStudentId.collectAsStateWithLifecycle()
    val isAddStudentOpen by viewModel.isAddStudentOpen.collectAsStateWithLifecycle()
    val studentToEdit by viewModel.studentToEdit.collectAsStateWithLifecycle()
    val paymentTargetStudent by viewModel.paymentTargetStudent.collectAsStateWithLifecycle()
    val activeReceipt by viewModel.activeReceipt.collectAsStateWithLifecycle()
    val overdueList by viewModel.overdueSummaries.collectAsStateWithLifecycle()
    val instituteName by viewModel.instituteName.collectAsStateWithLifecycle()

    // Sub-Screen 1: Add or Edit Student
    if (isAddStudentOpen) {
        BackHandler {
            viewModel.closeAddStudent()
        }
        AddStudentScreen(
            viewModel = viewModel,
            existingStudent = studentToEdit,
            onBack = { viewModel.closeAddStudent() }
        )
        return
    }

    // Sub-Screen 2: Student Detail Screen
    if (selectedStudentId != null) {
        BackHandler {
            viewModel.selectStudent(null)
        }
        StudentDetailScreen(
            studentId = selectedStudentId!!,
            viewModel = viewModel,
            onBack = { viewModel.selectStudent(null) }
        )
        return
    }

    // Top-Level Main Tabs Layout
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                // 1. Dashboard Tab
                NavigationBarItem(
                    selected = selectedTab == MainTab.DASHBOARD,
                    onClick = { selectedTab = MainTab.DASHBOARD },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.DASHBOARD) Icons.Filled.Dashboard else Icons.Outlined.Dashboard,
                            contentDescription = "Dashboard"
                        )
                    },
                    label = { Text("Dashboard") },
                    modifier = Modifier.testTag("nav_tab_dashboard")
                )

                // 2. Overdue Deck Tab (with badge count!)
                NavigationBarItem(
                    selected = selectedTab == MainTab.OVERDUE,
                    onClick = { selectedTab = MainTab.OVERDUE },
                    icon = {
                        if (overdueList.isNotEmpty()) {
                            BadgedBox(
                                badge = {
                                    Badge(
                                        containerColor = OverdueRed,
                                        contentColor = androidx.compose.ui.graphics.Color.White
                                    ) {
                                        Text("${overdueList.size}")
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (selectedTab == MainTab.OVERDUE) Icons.Filled.Warning else Icons.Outlined.Warning,
                                    contentDescription = "Overdue"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = if (selectedTab == MainTab.OVERDUE) Icons.Filled.Warning else Icons.Outlined.Warning,
                                contentDescription = "Overdue"
                            )
                        }
                    },
                    label = { Text("Overdue") },
                    modifier = Modifier.testTag("nav_tab_overdue")
                )

                // 3. All Students Tab
                NavigationBarItem(
                    selected = selectedTab == MainTab.STUDENTS,
                    onClick = { selectedTab = MainTab.STUDENTS },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.STUDENTS) Icons.Filled.People else Icons.Outlined.People,
                            contentDescription = "Students"
                        )
                    },
                    label = { Text("Students") },
                    modifier = Modifier.testTag("nav_tab_students")
                )

                // 4. Payments Ledger Tab
                NavigationBarItem(
                    selected = selectedTab == MainTab.PAYMENTS,
                    onClick = { selectedTab = MainTab.PAYMENTS },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.PAYMENTS) Icons.Filled.Payment else Icons.Outlined.Payment,
                            contentDescription = "Payments"
                        )
                    },
                    label = { Text("Payments") },
                    modifier = Modifier.testTag("nav_tab_payments")
                )
                // 5. Settings
                NavigationBarItem(
                    selected = selectedTab == MainTab.SETTINGS,
                    onClick = { selectedTab = MainTab.SETTINGS },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "Settings"
                        )
                    },
                    label = { Text("Settings") },
                    modifier = Modifier.testTag("nav_tab_settings")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                MainTab.DASHBOARD -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToOverdue = { selectedTab = MainTab.OVERDUE },
                    onNavigateToStudents = { selectedTab = MainTab.STUDENTS },
                    onNavigateToPayments = { selectedTab = MainTab.PAYMENTS },
                    onStudentClick = { studentId -> viewModel.selectStudent(studentId) },
                    onAddStudentClick = { viewModel.openAddStudent() }
                )
                MainTab.OVERDUE -> OverdueScreen(
                    viewModel = viewModel,
                    onStudentClick = { studentId -> viewModel.selectStudent(studentId) }
                )
                MainTab.STUDENTS -> StudentsScreen(
                    viewModel = viewModel,
                    onStudentClick = { studentId -> viewModel.selectStudent(studentId) },
                    onAddStudentClick = { viewModel.openAddStudent() }
                )
                MainTab.PAYMENTS -> PaymentsScreen(
                    viewModel = viewModel,
                    onStudentClick = { studentId -> viewModel.selectStudent(studentId) }
                )
                MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }

    // Modal: Receive Payment Bottom Sheet
    if (paymentTargetStudent != null) {
        AddPaymentBottomSheet(
            student = paymentTargetStudent!!,
            viewModel = viewModel,
            onDismiss = { viewModel.closeReceivePayment() }
        )
    }

    // Modal: Payment Receipt Dialog
    if (activeReceipt != null) {
        ReceiptDialog(
            receipt = activeReceipt!!,
            onDismiss = { viewModel.dismissReceipt() }
        )
    }
}

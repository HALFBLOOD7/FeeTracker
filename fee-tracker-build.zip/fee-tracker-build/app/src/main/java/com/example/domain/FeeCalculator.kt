package com.example.domain

import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity
import com.example.data.model.StudentFeeSummary
import com.example.data.model.StudentWithDetails
import com.example.util.DateUtils
import java.net.URLEncoder

object FeeCalculator {

    /**
     * Calculates the FeeSummary for a StudentWithDetails given the reference timestamp (default now).
     */
    fun calculateSummary(
        details: StudentWithDetails,
        referenceTime: Long = System.currentTimeMillis()
    ): StudentFeeSummary {
        val student = details.student
        val payments = details.payments
        val installments = details.installments

        // 1. Paid = SUM(SELECT(Payments[Amount],[StudentID]=[_THISROW].[StudentID]))
        val paid = payments.sumOf { it.amount }

        // 2. Expected based on PlanType
        val todayEndOfDay = DateUtils.getEndOfDay(referenceTime)
        var periodsDue = 0

        val expected = when (student.planType) {
            StudentEntity.PLAN_ADVANCE -> {
                if (student.startDate <= todayEndOfDay) student.totalFee else 0.0
            }
            StudentEntity.PLAN_MONTHLY -> {
                periodsDue = DateUtils.calculateMonthlyPeriodsDue(student.startDate, referenceTime)
                student.monthlyFee * periodsDue
            }
            StudentEntity.PLAN_INSTALLMENT -> {
                installments
                    .filter { it.dueDate <= todayEndOfDay }
                    .sumOf { it.amount }
            }
            else -> 0.0
        }

        // 3. Overdue = MAX(0, [Expected] - [Paid])
        val overdue = maxOf(0.0, expected - paid)

        // 4. Status = IF([Overdue]>0,"Overdue",IF(AND([PlanType]<>"Monthly",[Paid]>=[TotalFee]),"Cleared","On track"))
        val status = when {
            overdue > 0.0 -> StudentFeeSummary.STATUS_OVERDUE
            student.planType != StudentEntity.PLAN_MONTHLY && paid >= student.totalFee -> StudentFeeSummary.STATUS_CLEARED
            else -> StudentFeeSummary.STATUS_ON_TRACK
        }

        // 5. WaLink
        val waLink = generateWhatsAppLink(
            phone = student.phone,
            parentName = student.parentName,
            studentName = student.name,
            overdue = overdue
        )

        return StudentFeeSummary(
            student = student,
            paid = paid,
            expected = expected,
            overdue = overdue,
            status = status,
            waLink = waLink,
            installments = installments.sortedBy { it.dueDate },
            payments = payments.sortedByDescending { it.payDate },
            periodsDue = periodsDue
        )
    }

    /**
     * Generates:
     * CONCATENATE("https://wa.me/",[Phone],"?text=",ENCODEURL(CONCATENATE("Dear ",[Parent],", fee of Rs ",[Overdue]," for ",[Name]," is pending. Kindly pay at the earliest. Thank you.")))
     */
    fun generateWhatsAppLink(
        phone: String,
        parentName: String,
        studentName: String,
        overdue: Double
    ): String {
        val cleanPhone = phone.replace(Regex("[^0-9]"), "")
        // If 10 digit Indian number without country code, prefix 91
        val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
        val overdueStr = if (overdue % 1.0 == 0.0) {
            overdue.toLong().toString()
        } else {
            "%.2f".format(overdue)
        }
        val message = "Dear $parentName, fee of Rs $overdueStr for $studentName is pending. Kindly pay at the earliest. Thank you."
        val encodedText = try {
            URLEncoder.encode(message, "UTF-8")
        } catch (e: Exception) {
            message.replace(" ", "%20")
        }
        return "https://wa.me/$formattedPhone?text=$encodedText"
    }

    fun generateReceiptText(
        studentName: String,
        className: String,
        parentName: String,
        amount: Double,
        mode: String,
        payDate: Long,
        note: String,
        remainingOverdue: Double
    ): String {
        val amountStr = if (amount % 1.0 == 0.0) amount.toLong().toString() else "%.2f".format(amount)
        val remainingStr = if (remainingOverdue % 1.0 == 0.0) remainingOverdue.toLong().toString() else "%.2f".format(remainingOverdue)
        val dateStr = DateUtils.formatDate(payDate)
        val noteSection = if (note.isNotBlank()) " (Note: $note)" else ""

        return buildString {
            append("🎓 *Elevation Study Point - Fee Receipt*\n\n")
            append("Received with thanks from *$studentName* ($className)\n")
            append("Parent: $parentName\n")
            append("• Amount: *Rs $amountStr*\n")
            append("• Mode: $mode$noteSection\n")
            append("• Date: $dateStr\n")
            append("• Balance Overdue: Rs $remainingStr\n\n")
            append("Thank you for your prompt payment!")
        }
    }
}

package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.FeeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(viewModel: FeeViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val instituteName by viewModel.instituteName.collectAsStateWithLifecycle()
    val students by viewModel.allSummaries.collectAsStateWithLifecycle()
    val payments by viewModel.allPayments.collectAsStateWithLifecycle()
    var editedName by remember(instituteName) { mutableStateOf(instituteName) }
    var savedMessage by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Personalize your fee tracker and manage your records.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Institute profile", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = editedName,
                        onValueChange = { editedName = it.take(80); savedMessage = false },
                        label = { Text("Institute / coaching centre name") },
                        leadingIcon = { androidx.compose.material3.Icon(Icons.Default.School, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { viewModel.saveInstituteName(editedName); editedName = editedName.trim(); savedMessage = editedName.isNotBlank() },
                        enabled = editedName.trim().isNotBlank() && editedName.trim() != instituteName,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save institute name") }
                    if (savedMessage) Text("Institute name saved.", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Export records", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Share a CSV snapshot of students and payment history. The export may contain personal information; share it only with trusted recipients.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(
                        onClick = {
                            fun csv(value: String): String = "\"${value.replace("\"", "\"\"")}\""
                            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                            val builder = StringBuilder()
                            builder.appendLine("STUDENTS")
                            builder.appendLine("Student ID,Name,Class,Parent,Phone,Plan,Expected,Collected,Overdue,Status,Active")
                            students.forEach { student ->
                                builder.appendLine(listOf(
                                    student.studentId, student.name, student.className, student.parentName,
                                    student.phone, student.planType, student.expected.toString(), student.paid.toString(),
                                    student.overdue.toString(), student.status, student.active.toString()
                                ).joinToString(",") { csv(it) })
                            }
                            builder.appendLine()
                            builder.appendLine("PAYMENTS")
                            builder.appendLine("Payment ID,Student ID,Date,Amount,Mode,Note")
                            payments.forEach { payment ->
                                builder.appendLine(listOf(
                                    payment.payId, payment.studentId, dateFormat.format(Date(payment.payDate)),
                                    payment.amount.toString(), payment.mode, payment.note
                                ).joinToString(",") { csv(it) })
                            }
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_SUBJECT, "Fee Tracker data export")
                                putExtra(Intent.EXTRA_TEXT, builder.toString())
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Export fee records"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.FileDownload, contentDescription = null)
                        Spacer(Modifier.height(0.dp))
                        Text("Export students and payments (CSV)")
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Data and privacy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Your records are stored in this app's local database. Uninstalling the app or clearing its storage may remove them. Keep a secure export backup, and avoid sharing student or payment details publicly.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Demo records are no longer inserted automatically. Newly installed databases start empty.", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            Text("Fee Tracker · Version 1.0", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

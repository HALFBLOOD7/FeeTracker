package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.data.ImportExportCsv
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.FeeViewModel

@Composable
fun SettingsScreen(viewModel: FeeViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val instituteName by viewModel.instituteName.collectAsStateWithLifecycle()
    val students by viewModel.allSummaries.collectAsStateWithLifecycle()
    val payments by viewModel.allPayments.collectAsStateWithLifecycle()
    var editedName by remember(instituteName) { mutableStateOf(instituteName) }
    var savedMessage by remember { mutableStateOf(false) }
    var dataMessage by remember { mutableStateOf("") }
    var pendingExport by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val csv = pendingExport
        pendingExport = null
        if (uri != null && csv != null) {
            dataMessage = "Saving backup…"
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(csv) }
                            ?: error("Could not save the selected file")
                    }
                }
                dataMessage = result.fold(
                    onSuccess = { "Backup saved successfully. Keep the file somewhere safe." },
                    onFailure = { "Export failed: ${it.message ?: "Could not save backup"}" }
                )
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            dataMessage = "Reading backup…"
            scope.launch {
                val parsed = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Could not open the selected file")
                    }.mapCatching(ImportExportCsv::decode)
                }
                parsed.fold(
                    onSuccess = { backup ->
                        viewModel.importBackup(backup.students, backup.installments, backup.payments) { result ->
                            dataMessage = result.fold(
                                onSuccess = { count -> "Import complete: $count new records added. Existing matching IDs were skipped." },
                                onFailure = { error -> "Import failed: ${error.message ?: "Unknown error"}" }
                            )
                        }
                    },
                    onFailure = { error -> dataMessage = "Import failed: ${error.message ?: "Invalid backup file"}" }
                )
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Personalize your fee tracker and manage your records.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Institute profile", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = editedName,
                        onValueChange = { editedName = it.take(80); savedMessage = false },
                        label = { Text("Institute / coaching centre name") },
                        leadingIcon = { androidx.compose.material3.Icon(Icons.Default.School, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { viewModel.saveInstituteName(editedName); editedName = editedName.trim(); savedMessage = editedName.isNotBlank() },
                        enabled = editedName.trim().isNotBlank() && editedName.trim() != instituteName,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save institute name") }
                    if (savedMessage) Text("Institute name saved.", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backup and restore", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Save a complete backup file or import a previous Fee Tracker backup. Backups include student details, installment schedules and payment history.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(
                        onClick = {
                            val allStudents = students.map { it.student }
                            val allInstallments = students.flatMap { it.installments }
                            pendingExport = ImportExportCsv.encode(allStudents, allInstallments, payments)
                            dataMessage = ""
                            exportLauncher.launch("FeeTracker-backup.csv")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.FileDownload, contentDescription = null)
                        Text("Save full backup (CSV)")
                    }
                    Button(
                        onClick = { importLauncher.launch(arrayOf("text/*", "application/octet-stream")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.FileUpload, contentDescription = null)
                        Text("Import backup (CSV)")
                    }
                    Text("Import is additive: existing records with matching IDs are skipped; records are not deleted or overwritten. Use a CSV exported by Fee Tracker. Keep backups private because they contain student and payment information.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (dataMessage.isNotBlank()) {
                        Text(dataMessage, color = if (dataMessage.startsWith("Import failed")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Data and privacy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Your records are stored in this app's local database. Uninstalling the app or clearing its storage may remove them. Keep a secure export backup, and avoid sharing student or payment details publicly.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Demo records are no longer inserted automatically. Newly installed databases start empty.", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            Text("Fee Tracker · Version 1.0", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

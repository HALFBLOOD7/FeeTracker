package com.example.data.model

data class StudentFeeSummary(
    val student: StudentEntity,
    val paid: Double,
    val expected: Double,
    val overdue: Double,
    val status: String, // "Overdue", "Cleared", "On track"
    val waLink: String,
    val installments: List<InstallmentEntity> = emptyList(),
    val payments: List<PaymentEntity> = emptyList(),
    val periodsDue: Int = 0
) {
    val studentId: String get() = student.studentId
    val name: String get() = student.name
    val className: String get() = student.className
    val parentName: String get() = student.parentName
    val phone: String get() = student.phone
    val planType: String get() = student.planType
    val totalFee: Double get() = student.totalFee
    val monthlyFee: Double get() = student.monthlyFee
    val startDate: Long get() = student.startDate
    val active: Boolean get() = student.active

    val isOverdue: Boolean get() = status == STATUS_OVERDUE
    val isCleared: Boolean get() = status == STATUS_CLEARED
    val isOnTrack: Boolean get() = status == STATUS_ON_TRACK

    companion object {
        const val STATUS_OVERDUE = "Overdue"
        const val STATUS_CLEARED = "Cleared"
        const val STATUS_ON_TRACK = "On track"
    }
}

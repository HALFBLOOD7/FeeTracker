package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = StudentEntity::class,
            parentColumns = ["studentId"],
            childColumns = ["studentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["studentId"])]
)
data class PaymentEntity(
    @PrimaryKey
    val payId: String = UUID.randomUUID().toString(),
    val studentId: String,
    val payDate: Long = System.currentTimeMillis(),
    val amount: Double,
    val mode: String, // "Cash", "UPI", "Bank", "Cheque"
    val note: String = ""
) {
    companion object {
        const val MODE_CASH = "Cash"
        const val MODE_UPI = "UPI"
        const val MODE_BANK = "Bank"
        const val MODE_CHEQUE = "Cheque"

        val ALL_MODES = listOf(MODE_CASH, MODE_UPI, MODE_BANK, MODE_CHEQUE)
    }
}

package com.example.data.model

import androidx.room.Embedded
import androidx.room.Relation

data class StudentWithDetails(
    @Embedded
    val student: StudentEntity,

    @Relation(
        parentColumn = "studentId",
        entityColumn = "studentId"
    )
    val installments: List<InstallmentEntity> = emptyList(),

    @Relation(
        parentColumn = "studentId",
        entityColumn = "studentId"
    )
    val payments: List<PaymentEntity> = emptyList()
)

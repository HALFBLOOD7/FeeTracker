package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudentEntity
import com.example.data.model.StudentFeeSummary
import com.example.ui.theme.ClearedContainer
import com.example.ui.theme.ClearedGreen
import com.example.ui.theme.OnClearedContainer
import com.example.ui.theme.OnOverdueContainer
import com.example.ui.theme.OnTrackBlue
import com.example.ui.theme.OnTrackContainer
import com.example.ui.theme.OverdueContainer
import com.example.ui.theme.OverdueRed

fun formatCurrency(amount: Double): String {
    return if (amount % 1.0 == 0.0) {
        "%,d".format(amount.toLong())
    } else {
        "%,.2f".format(amount)
    }
}

@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, label) = when (status) {
        StudentFeeSummary.STATUS_OVERDUE -> Triple(OverdueContainer, OverdueRed, "Overdue")
        StudentFeeSummary.STATUS_CLEARED -> Triple(ClearedContainer, ClearedGreen, "Cleared")
        else -> Triple(OnTrackContainer, OnTrackBlue, "On Track")
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = textColor,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )
        }
    }
}

@Composable
fun PlanBadge(planType: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (planType) {
        StudentEntity.PLAN_MONTHLY -> Color(0xFFF3E8FF) to Color(0xFF7E22CE)
        StudentEntity.PLAN_INSTALLMENT -> Color(0xFFFEF3C7) to Color(0xFFB45309)
        else -> Color(0xFFE0E7FF) to Color(0xFF4338CA)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = planType,
            color = textColor,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun StudentActionButtons(
    summary: StudentFeeSummary,
    onReceivePayment: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. Call Button
        OutlinedButton(
            onClick = {
                launchDialer(context, summary.phone)
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .testTag("action_call_${summary.studentId}"),
            contentPadding = ButtonDefaults.ContentPadding
        ) {
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = "Call Parent",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Call", fontSize = 13.sp)
        }

        // 2. WhatsApp Button
        FilledTonalButton(
            onClick = {
                launchWhatsApp(context, summary.waLink)
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = Color(0xFFDCFCE7),
                contentColor = Color(0xFF15803D)
            ),
            modifier = Modifier
                .weight(1.3f)
                .height(44.dp)
                .testTag("action_whatsapp_${summary.studentId}")
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "WhatsApp Reminder",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "WhatsApp", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }

        // 3. Receive Payment Button
        Button(
            onClick = onReceivePayment,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier
                .weight(1.5f)
                .height(44.dp)
                .testTag("action_receive_payment_${summary.studentId}")
        ) {
            Icon(
                imageVector = Icons.Default.Payment,
                contentDescription = "Collect Fee",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Collect", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

fun launchDialer(context: Context, phone: String) {
    try {
        val clean = phone.replace(Regex("[^0-9+]"), "")
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$clean")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open dialer for $phone", Toast.LENGTH_SHORT).show()
    }
}

fun launchWhatsApp(context: Context, waUrl: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(waUrl)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open WhatsApp link", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun EmptyStateView(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionButton: (@Composable () -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (actionButton != null) {
            Spacer(modifier = Modifier.height(16.dp))
            actionButton()
        }
    }
}

# Fee Tracker — Android Build Package

An Android fee-tracking application built with Kotlin, Jetpack Compose, and Room.

## Requirements

- Android Studio (current stable release recommended)
- Android SDK Platform 36 (or allow Android Studio to install the required SDK)
- JDK 17 for the Gradle/Android toolchain
- Internet access on the build machine to download Gradle and dependencies

## Build a debug APK

1. Extract this ZIP to a writable folder.
2. Open Android Studio and choose **Open**.
3. Select the extracted project folder (the one containing `settings.gradle.kts`).
4. Allow Gradle sync to complete. Install any SDK components Android Studio requests.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, after configuring Gradle on your machine, run `gradle assembleDebug` from the project root.

## Signing

Debug builds use Android Gradle Plugin's standard debug signing. No personal keystore is required.
Release builds are not signed by this project configuration. Configure a private release signing key locally before publishing; never place signing passwords or private keystores in a shared ZIP.

## Configuration

`.env.example` is a template. If a feature requires a Gemini API key, create a local `.env` file from that template and supply your own key. Do not commit or share real API keys.

## Changes included

- Removed the dashboard reset-demo-data control and automatic demo-data seeding; new installs start empty.
- Added Settings for institute name and CSV export of student/payment data.
- Uses the institute name in the dashboard and receipts.
- Caps monthly expected fees at the configured total course fee and supports cleared status after the contracted fee is paid.
- Added a unit test for monthly fee capping and cleared status.
- Removed project-specific debug/release keystore file dependencies so the project can be opened and debug-built without missing `debug.keystore` or `my-upload-key.jks` files.

## Important

This ZIP contains the Android Studio project source, not a prebuilt APK. The Gradle wrapper JAR was not available in the supplied project, so open the project in Android Studio to sync/build it, or install Gradle locally and use the command above. The project has not been compiled in this environment; build and run the tests before using it with real student records.

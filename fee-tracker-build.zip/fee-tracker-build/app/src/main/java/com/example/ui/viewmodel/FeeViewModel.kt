package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FeeRepository
import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity
import com.example.data.model.StudentFeeSummary
import com.example.data.model.StudentWithDetails
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardKpis(
    val totalExpected: Double = 0.0,
    val totalCollected: Double = 0.0,
    val totalOverdue: Double = 0.0,
    val totalActiveStudents: Int = 0,
    val overdueStudentsCount: Int = 0,
    val clearedStudentsCount: Int = 0,
    val onTrackStudentsCount: Int = 0
)

class FeeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FeeRepository

    init {
        val database = AppDatabase.getInstance(application)
        repository = FeeRepository(database.feeDao())
        viewModelScope.launch {
            repository.checkAndSeedIfEmpty()
        }
    }

    val allSummaries: StateFlow<List<StudentFeeSummary>> = repository.allSummaries
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val overdueSummaries: StateFlow<List<StudentFeeSummary>> = repository.overdueSummaries
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allPayments: StateFlow<List<PaymentEntity>> = repository.allPayments
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filter states for All Students view
    val studentSearchQuery = MutableStateFlow("")
    val selectedPlanFilter = MutableStateFlow("All") // "All", "Monthly", "Installment", "Advance"
    val selectedStatusFilter = MutableStateFlow("All") // "All", "Overdue", "On track", "Cleared"
    val activeOnlyFilter = MutableStateFlow(true)

    // Filtered students for All Students view
    val filteredStudents: StateFlow<List<StudentFeeSummary>> = combine(
        allSummaries,
        studentSearchQuery,
        selectedPlanFilter,
        selectedStatusFilter,
        activeOnlyFilter
    ) { summaries, query, plan, status, activeOnly ->
        summaries.filter { summary ->
            val matchesQuery = query.isBlank() ||
                summary.name.contains(query, ignoreCase = true) ||
                summary.className.contains(query, ignoreCase = true) ||
                summary.parentName.contains(query, ignoreCase = true) ||
                summary.phone.contains(query)

            val matchesPlan = plan == "All" || summary.planType == plan
            val matchesStatus = status == "All" || summary.status == status
            val matchesActive = !activeOnly || summary.active

            matchesQuery && matchesPlan && matchesStatus && matchesActive
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Payment search and filter
    val paymentSearchQuery = MutableStateFlow("")
    val selectedPaymentMode = MutableStateFlow("All")

    val filteredPayments: StateFlow<List<Pair<PaymentEntity, StudentFeeSummary?>>> = combine(
        allPayments,
        allSummaries,
        paymentSearchQuery,
        selectedPaymentMode
    ) { payments, summaries, query, mode ->
        val summaryMap = summaries.associateBy { it.studentId }
        payments
            .map { payment -> payment to summaryMap[payment.studentId] }
            .filter { (payment, summary) ->
                val matchesMode = mode == "All" || payment.mode == mode
                val matchesQuery = query.isBlank() ||
                    (summary?.name?.contains(query, ignoreCase = true) == true) ||
                    (summary?.className?.contains(query, ignoreCase = true) == true) ||
                    payment.note.contains(query, ignoreCase = true) ||
                    payment.mode.contains(query, ignoreCase = true)
                matchesMode && matchesQuery
            }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Dashboard KPIs
    val dashboardKpis: StateFlow<DashboardKpis> = combine(
        allSummaries,
        allPayments
    ) { summaries, payments ->
        val activeStudents = summaries.filter { it.active }
        val totalExpected = activeStudents.sumOf { it.expected }
        val totalCollected = payments.sumOf { it.amount }
        val totalOverdue = activeStudents.sumOf { it.overdue }
        val overdueCount = activeStudents.count { it.isOverdue }
        val clearedCount = activeStudents.count { it.isCleared }
        val onTrackCount = activeStudents.count { it.isOnTrack }

        DashboardKpis(
            totalExpected = totalExpected,
            totalCollected = totalCollected,
            totalOverdue = totalOverdue,
            totalActiveStudents = activeStudents.size,
            overdueStudentsCount = overdueCount,
            clearedStudentsCount = clearedCount,
            onTrackStudentsCount = onTrackCount
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardKpis()
    )

    // Selected student detail view
    private val _selectedStudentId = MutableStateFlow<String?>(null)
    val selectedStudentId: StateFlow<String?> = _selectedStudentId.asStateFlow()

    val selectedStudentDetails: StateFlow<StudentFeeSummary?> = _selectedStudentId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else repository.getStudentSummary(id)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun selectStudent(studentId: String?) {
        _selectedStudentId.value = studentId
    }

    // Quick Payment dialog state
    private val _paymentTargetStudent = MutableStateFlow<StudentFeeSummary?>(null)
    val paymentTargetStudent: StateFlow<StudentFeeSummary?> = _paymentTargetStudent.asStateFlow()

    fun openReceivePayment(student: StudentFeeSummary) {
        _paymentTargetStudent.value = student
    }

    fun closeReceivePayment() {
        _paymentTargetStudent.value = null
    }

    // Receipt display dialog state
    data class ReceiptData(
        val payment: PaymentEntity,
        val studentName: String,
        val className: String,
        val parentName: String,
        val phone: String,
        val remainingOverdue: Double
    )

    private val _activeReceipt = MutableStateFlow<ReceiptData?>(null)
    val activeReceipt: StateFlow<ReceiptData?> = _activeReceipt.asStateFlow()

    fun showReceipt(receipt: ReceiptData) {
        _activeReceipt.value = receipt
    }

    fun dismissReceipt() {
        _activeReceipt.value = null
    }

    // Add / Edit Student sheet
    private val _isAddStudentOpen = MutableStateFlow(false)
    val isAddStudentOpen: StateFlow<Boolean> = _isAddStudentOpen.asStateFlow()

    private val _studentToEdit = MutableStateFlow<StudentWithDetails?>(null)
    val studentToEdit: StateFlow<StudentWithDetails?> = _studentToEdit.asStateFlow()

    fun openAddStudent(studentWithDetails: StudentWithDetails? = null) {
        _studentToEdit.value = studentWithDetails
        _isAddStudentOpen.value = true
    }

    fun closeAddStudent() {
        _studentToEdit.value = null
        _isAddStudentOpen.value = false
    }

    // Database Actions
    fun recordPayment(
        studentId: String,
        amount: Double,
        mode: String,
        note: String,
        payDate: Long,
        onSuccess: (PaymentEntity, StudentFeeSummary?) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val payment = PaymentEntity(
                studentId = studentId,
                amount = amount,
                mode = mode,
                note = note,
                payDate = payDate
            )
            repository.recordPayment(payment)

            // Find student summary to prepare receipt
            val currentSummary = allSummaries.value.find { it.studentId == studentId }
            onSuccess(payment, currentSummary)
        }
    }

    fun saveStudent(
        student: StudentEntity,
        installments: List<InstallmentEntity>
    ) {
        viewModelScope.launch {
            repository.saveStudentWithInstallments(student, installments)
            closeAddStudent()
        }
    }

    fun toggleStudentActive(student: StudentEntity) {
        viewModelScope.launch {
            repository.updateStudent(student.copy(active = !student.active))
        }
    }

    fun deleteStudent(student: StudentEntity) {
        viewModelScope.launch {
            repository.deleteStudent(student)
            if (_selectedStudentId.value == student.studentId) {
                _selectedStudentId.value = null
            }
        }
    }

    fun deletePayment(payment: PaymentEntity) {
        viewModelScope.launch {
            repository.deletePayment(payment)
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetWithDemoData()
            _selectedStudentId.value = null
        }
    }
}

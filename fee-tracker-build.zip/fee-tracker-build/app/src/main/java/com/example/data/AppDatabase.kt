package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.FeeDao
import com.example.data.model.InstallmentEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.StudentEntity
import com.example.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        StudentEntity::class,
        InstallmentEntity::class,
        PaymentEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun feeDao(): FeeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "feetracker.db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedInitialData(database.feeDao())
                    }
                }
            }
        }

        suspend fun seedInitialData(dao: FeeDao) {
            val student1Id = UUID.randomUUID().toString()
            val student2Id = UUID.randomUUID().toString()
            val student3Id = UUID.randomUUID().toString()
            val student4Id = UUID.randomUUID().toString()

            // 1. Advance Plan (Past StartDate: 35 days ago, Total: ₹25,000, Paid: ₹10,000, Overdue: ₹15,000)
            val student1 = StudentEntity(
                studentId = student1Id,
                name = "Aarav Sharma",
                className = "Class 10-A",
                parentName = "Rajesh Sharma",
                phone = "9876543210",
                planType = StudentEntity.PLAN_ADVANCE,
                totalFee = 25000.0,
                monthlyFee = 0.0,
                startDate = DateUtils.daysAgo(35),
                active = true
            )

            val student1Payment = PaymentEntity(
                payId = UUID.randomUUID().toString(),
                studentId = student1Id,
                payDate = DateUtils.daysAgo(25),
                amount = 10000.0,
                mode = PaymentEntity.MODE_UPI,
                note = "Advance token payment via UPI"
            )

            // 2. Monthly Plan (Past StartDate: ~65 days ago, ₹3,500/mo, 3 periods due = ₹10,500, Paid: ₹7,000, Overdue: ₹3,500)
            val student2 = StudentEntity(
                studentId = student2Id,
                name = "Priya Patel",
                className = "Class 9-B",
                parentName = "Suresh Patel",
                phone = "9823456789",
                planType = StudentEntity.PLAN_MONTHLY,
                totalFee = 42000.0,
                monthlyFee = 3500.0,
                startDate = DateUtils.daysAgo(65),
                active = true
            )

            val student2Payment1 = PaymentEntity(
                payId = UUID.randomUUID().toString(),
                studentId = student2Id,
                payDate = DateUtils.daysAgo(60),
                amount = 3500.0,
                mode = PaymentEntity.MODE_CASH,
                note = "Month 1 fee"
            )

            val student2Payment2 = PaymentEntity(
                payId = UUID.randomUUID().toString(),
                studentId = student2Id,
                payDate = DateUtils.daysAgo(30),
                amount = 3500.0,
                mode = PaymentEntity.MODE_UPI,
                note = "Month 2 fee"
            )

            // 3. Installment Plan (Total: ₹40,000 across 3 installments: Inst 1 due 45 days ago ₹15,000, Inst 2 due 10 days ago ₹15,000, Inst 3 due in 30 days ₹10,000)
            // Expected by today = ₹30,000. Paid: ₹15,000. Overdue: ₹15,000.
            val student3 = StudentEntity(
                studentId = student3Id,
                name = "Rohan Verma",
                className = "Class 12-Science",
                parentName = "Sunil Verma",
                phone = "9812345670",
                planType = StudentEntity.PLAN_INSTALLMENT,
                totalFee = 40000.0,
                monthlyFee = 0.0,
                startDate = DateUtils.daysAgo(50),
                active = true
            )

            val inst1 = InstallmentEntity(
                instId = UUID.randomUUID().toString(),
                studentId = student3Id,
                dueDate = DateUtils.daysAgo(45),
                amount = 15000.0
            )

            val inst2 = InstallmentEntity(
                instId = UUID.randomUUID().toString(),
                studentId = student3Id,
                dueDate = DateUtils.daysAgo(10),
                amount = 15000.0
            )

            val inst3 = InstallmentEntity(
                instId = UUID.randomUUID().toString(),
                studentId = student3Id,
                dueDate = DateUtils.daysFromNow(30),
                amount = 10000.0
            )

            val student3Payment = PaymentEntity(
                payId = UUID.randomUUID().toString(),
                studentId = student3Id,
                payDate = DateUtils.daysAgo(40),
                amount = 15000.0,
                mode = PaymentEntity.MODE_BANK,
                note = "1st Installment NEFT transfer"
            )

            // 4. Cleared Student (Advance Plan, Total ₹18,000, Paid: ₹18,000 -> Status: Cleared)
            val student4 = StudentEntity(
                studentId = student4Id,
                name = "Ananya Gupta",
                className = "Class 11-Commerce",
                parentName = "Manoj Gupta",
                phone = "9898989898",
                planType = StudentEntity.PLAN_ADVANCE,
                totalFee = 18000.0,
                monthlyFee = 0.0,
                startDate = DateUtils.daysAgo(40),
                active = true
            )

            val student4Payment = PaymentEntity(
                payId = UUID.randomUUID().toString(),
                studentId = student4Id,
                payDate = DateUtils.daysAgo(38),
                amount = 18000.0,
                mode = PaymentEntity.MODE_CHEQUE,
                note = "Full annual fee via Cheque #492810"
            )

            dao.saveStudentWithInstallments(student1, emptyList())
            dao.insertPayment(student1Payment)

            dao.saveStudentWithInstallments(student2, emptyList())
            dao.insertPayment(student2Payment1)
            dao.insertPayment(student2Payment2)

            dao.saveStudentWithInstallments(student3, listOf(inst1, inst2, inst3))
            dao.insertPayment(student3Payment)

            dao.saveStudentWithInstallments(student4, emptyList())
            dao.insertPayment(student4Payment)
        }
    }
}
